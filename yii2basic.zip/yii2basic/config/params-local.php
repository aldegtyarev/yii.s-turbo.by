<?php

return [
    'adminEmail' => '',
	'supportEmail' => '',
];
